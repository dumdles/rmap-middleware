<?php
// api/get-sign-up-requests.php

require_once __DIR__ . '/../../src/middleware.php';
require_once __DIR__ . '/../../src/config.php';

header('Content-Type: application/json');

try {
    $db = getDBconnection();

    $stmt = $db->prepare("SELECT ID, User_Name, Name, email, signup_date FROM sign_up_users");
    $stmt->execute();
    $result = $stmt->get_result();

    $signUpRequests = [];
    while ($row = $result->fetch_assoc()) {
        $signupDate = (new DateTime($row['signup_date'], new DateTimeZone('UTC')))->format('c'); // 'c' gives ISO 8601 with 'T' and 'Z'

        // Create a DateTime object from the signup date
        $dateTime = new DateTime($signupDate, new DateTimeZone('Asia/Singapore')); // Replace with your server's time zone if different
        $dateTime->setTimezone(new DateTimeZone('UTC')); // Convert to UTC
        $row['signup_date'] = $dateTime->format('c'); // ISO 8601 format

        $signUpRequests[] = $row;
    }

    echo json_encode([
        'success' => true,
        'data' => $signUpRequests
    ]);

    $stmt->close();
    $db->close();
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
}
